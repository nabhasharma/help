import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-typography-section',
  templateUrl: './typography-section.component.html',
  styleUrls: ['./typography-section.component.css']
})
export class TypographySectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
